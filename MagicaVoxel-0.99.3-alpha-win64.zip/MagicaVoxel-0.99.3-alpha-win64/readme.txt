[MagicaVoxel : 8-bit Voxel Editor & Renderer]
================================
date    : 2/2/2019

version : 0.99.3a

os      : Win32, MacOS 10.7+

website : https://ephtracy.github.io/

twitter : @ ephtracy

[Credits]
================================
Icon : Font Awesome Free Version : https://fontawesome.com/
Icon : Google Material Design : https://material.io/tools/icons/?style=baseline
Icon : Ionicons : https://ionicons.com/
SDF Font : https://github.com/evanw/font-texture-generator